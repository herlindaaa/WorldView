package com.example.worldview;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;
import java.util.HashMap;

public class Pesawat extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Spinner spinAsal, spinTujuan, spinDewasa, spinAnak;
    SessionManager session;
    String email;
    int id_book;
    public String sAsal, sTujuan, sTanggal, sDewasa, sAnak;
    int jmlDewasa, jmlAnak;
    int hargaDewasa, hargaAnak;
    int hargaTotalDewasa, hargaTotalAnak, hargaTotal;
    private EditText edtTanggal;
    public Button btnBook;
    private DatePickerDialog dpTanggal;
    Calendar newCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesawat);
        dbHelper = new DatabaseHelper(Pesawat.this);
        db = dbHelper.getReadableDatabase();

        final String[] asal = {"Jakarta, Indonesia", "Surabaya, Indonesia", "Medan, Indonesia", "Singapore, Singapore", "Sydney, Australia", "Istanbul, Turkey"};
        final String[] tujuan = {"Jakarta, Indonesia", "Surabaya, Indonesia", "Medan, Indonesia", "Singapore, Singapore", "Sydney, Australia", "Istanbul, Turkey"};
        final String[] dewasa = {"1", "2", "3", "4", "5", "6", "7"};
        final String[] anak = {"0", "1", "2", "3", "4", "5", "6"};

        spinAsal = findViewById(R.id.asal);
        spinTujuan = findViewById(R.id.tujuan);
        spinDewasa = findViewById(R.id.dewasa);
        spinAnak = findViewById(R.id.anak);

        ArrayAdapter<CharSequence> adapterAsal = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, asal);
        adapterAsal.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinAsal.setAdapter(adapterAsal);
        ArrayAdapter<CharSequence> adapterTujuan = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tujuan);
        adapterTujuan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinTujuan.setAdapter(adapterTujuan);
        ArrayAdapter<CharSequence> adapterDewasa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dewasa);
        adapterDewasa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinDewasa.setAdapter(adapterDewasa);
        ArrayAdapter<CharSequence> adapterAnak = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, anak);
        adapterAnak.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinAnak.setAdapter(adapterAnak);

        spinAsal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sAsal = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinTujuan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sTujuan = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinDewasa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sDewasa = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinAnak.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sAnak = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btnBook = findViewById(R.id.book);
        edtTanggal = findViewById(R.id.tanggal);
        edtTanggal.setInputType(InputType.TYPE_NULL);
        edtTanggal.requestFocus();
        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        email = user.get(SessionManager.KEY_EMAIL);
        setDataTimeField();

        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                perhitunganHarga();
                if(sAsal != null && sTujuan != null && sTanggal != null && sDewasa != null) {
                    if((sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia"))
                            || (sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia"))
                            || (sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Medan, Indonesia"))
                            || (sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Singapore, Singapore"))
                            || (sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Sydney, Australia"))
                            || (sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Istanbul, Turkey"))){
                        Toast.makeText(Pesawat.this, "Asal dan Tujuan tidak boleh sama!", Toast.LENGTH_LONG).show();
                    } else {
                        AlertDialog dialog = new AlertDialog.Builder(Pesawat.this)
                                .setTitle("Ingin booking pesawat sekarang?")
                                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            db.execSQL("INSERT INTO TB_BOOK (asal, tujuan, tanggal, dewasa, anak) VALUES ('" +
                                                    sAsal + "','" +
                                                    sTujuan + "','" +
                                                    sTanggal + "','" +
                                                    sDewasa + "','" +
                                                    sAnak + "');");
                                            cursor = db.rawQuery("SELECT id_book FROM TB_BOOK ORDER BY id_book DESC", null);
                                            cursor.moveToLast();
                                            if(cursor.getCount() > 0){
                                                cursor.moveToPosition(0);
                                                id_book = cursor.getInt(0);
                                            }
                                            db.execSQL("INSERT INTO TB_HARGA (username, id_book, harga_dewasa, harga_anak, harga_total) VALUES ('" +
                                                    email + "','" +
                                                    id_book + "','" +
                                                    hargaTotalDewasa + "','" +
                                                    hargaTotalAnak + "','" +
                                                    hargaTotal + "');");
                                            Toast.makeText(Pesawat.this, "Booking Berhasil", Toast.LENGTH_LONG).show();
                                            finish();
                                        } catch (Exception e){
                                            Toast.makeText(Pesawat.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                })
                                .setNegativeButton("Tidak", null)
                                .create();
                        dialog.show();
                    }
                } else {
                    Toast.makeText(Pesawat.this, "Mohon Lengkapi Data Pemesanan!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void perhitunganHarga() {
        if(sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia")) {
            hargaDewasa = 730000;
            hargaAnak = 700000;
        } else if(sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Medan, Indonesia")) {
            hargaDewasa = 953000;
            hargaAnak = 900000;
        } else if(sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Singapore, Singapore")) {
            hargaDewasa = 896000;
            hargaAnak = 850000;
        } else if(sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Sydney, Australia")) {
            hargaDewasa = 5100000;
            hargaAnak = 5000000;
        } else if(sAsal.equalsIgnoreCase("Jakarta, Indonesia") && sTujuan.equalsIgnoreCase("Istanbul, Turkey")) {
            hargaDewasa = 17200000;
            hargaAnak = 17000000;
        } else if(sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia")) {
            hargaDewasa = 895000;
            hargaAnak = 875000;
        } else if(sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Medan, Indonesia")) {
            hargaDewasa = 2000000;
            hargaAnak = 1980000;
        } else if(sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Singapore, Singapore")) {
            hargaDewasa = 684000;
            hargaAnak = 664000;
        } else if(sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Sydney, Australia")){
            hargaDewasa = 4478000;
            hargaAnak = 4458000;
        } else if(sAsal.equalsIgnoreCase("Surabaya, Indonesia") && sTujuan.equalsIgnoreCase("Istanbul, Turkey")){
            hargaDewasa = 20300000;
            hargaAnak = 20280000;
        } else if(sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia")){
            hargaDewasa = 981000;
            hargaAnak = 961000;
        } else if(sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia")){
            hargaDewasa = 1811000;
            hargaAnak = 1791000;
        } else if(sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Singapore, Singapore")){
            hargaDewasa = 819000;
            hargaAnak = 799000;
        } else if(sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Sydney, Australia")){
            hargaDewasa = 5614000;
            hargaAnak = 5594000;
        } else if(sAsal.equalsIgnoreCase("Medan, Indonesia") && sTujuan.equalsIgnoreCase("Istanbul, Turkey")){
            hargaDewasa = 15100000;
            hargaAnak = 15000000;
        } else if(sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia")){
            hargaDewasa = 1550000;
            hargaAnak = 1530000;
        } else if(sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia")){
            hargaDewasa = 1400000;
            hargaAnak = 1380000;
        } else if(sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Medan, Indonesia")){
            hargaDewasa = 1530000;
            hargaAnak = 1510000;
        } else if(sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Sydney, Australia")){
            hargaDewasa = 5610000;
            hargaAnak = 5590000;
        } else if(sAsal.equalsIgnoreCase("Singapore, Singapore") && sTujuan.equalsIgnoreCase("Istanbul, Turkey")){
            hargaDewasa = 10890000;
            hargaAnak = 10870000;
        } else if(sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia")){
            hargaDewasa = 10790000;
            hargaAnak = 10770000;
        } else if(sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia")){
            hargaDewasa = 10790000;
            hargaAnak = 10770000;
        } else if(sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Medan, Indonesia")){
            hargaDewasa = 11880000;
            hargaAnak = 11860000;
        } else if(sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Singapore, Singapore")){
            hargaDewasa = 12880000;
            hargaAnak = 12860000;
        } else if(sAsal.equalsIgnoreCase("Sydney, Australia") && sTujuan.equalsIgnoreCase("Istanbul, Turkey")){
            hargaDewasa = 26900000;
            hargaAnak = 26880000;
        } else if(sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Jakarta, Indonesia")){
            hargaDewasa = 11710000;
            hargaAnak = 11690000;
        } else if(sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Surabaya, Indonesia")){
            hargaDewasa = 15970000;
            hargaAnak = 15950000;
        } else if(sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Medan, Indonesia")){
            hargaDewasa = 24370000;
            hargaAnak = 24350000;
        } else if(sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Singapore, Singapore")){
            hargaDewasa = 9820000;
            hargaAnak = 9800000;
        } else if(sAsal.equalsIgnoreCase("Istanbul, Turkey") && sTujuan.equalsIgnoreCase("Sydney, Australia")){
            hargaDewasa = 18000000;
            hargaAnak = 17980000;
        }
        jmlDewasa = Integer.parseInt(sDewasa);
        jmlAnak = Integer.parseInt(sAnak);
        hargaTotalDewasa = jmlDewasa * hargaDewasa;
        hargaTotalAnak = jmlAnak * hargaAnak;
        hargaTotal = hargaTotalDewasa + hargaTotalAnak;
    }
    private void setDataTimeField() {
        edtTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dpTanggal.show();
            }
        });
        dpTanggal = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                String[] bulan = {"January", "February", "March", "April", "May",
                        "June", "July", "August", "September", "October", "November", "December"};
                sTanggal = dayOfMonth + " " + bulan[monthOfYear] + " " + year;
                edtTanggal.setText(sTanggal);
            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
    }
}