package com.example.worldview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class SearchHotel extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RvHotelAdapter adapter;
    private RecyclerView.LayoutManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_hotel);

        ArrayList<HotelAdapter> hotelAdapter = new ArrayList<HotelAdapter>();
        hotelAdapter.add(new HotelAdapter(R.drawable.img, "Grand Tjokro Premiere Bandung", "Cihampelas, Bandung", "Rp. 1.1299.999"));
        hotelAdapter.add(new HotelAdapter(R.drawable.img_1, "eL Hotel Royale Bandung", "Merdeka, Bandung", "Rp. 1.466.325"));
        hotelAdapter.add(new HotelAdapter(R.drawable.img_2, "Four Points by Sheraton Bandung", "Dago, Bandung", "Rp. 2.034.833"));
        hotelAdapter.add(new HotelAdapter(R.drawable.img_3, "Swiss-Belresort Dago Heritage Bandung", "Dago Atas, Bandung", "Rp. 2.749.900"));

        recyclerView = findViewById(R.id.rvHotel);
        recyclerView.setHasFixedSize(true);
        manager = new LinearLayoutManager(this);
        adapter = new RvHotelAdapter(hotelAdapter);

        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);
    }
}