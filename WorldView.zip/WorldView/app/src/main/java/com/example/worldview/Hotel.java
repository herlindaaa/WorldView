package com.example.worldview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Calendar;
import java.util.HashMap;

public class Hotel extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Spinner spinLokasi, spinLama, spinKamar;
    SessionManager session;
    String email;
    int id_book;
    public String sLokasi, sLama, sKamar, sTanggal;
    int jmlKamar;
    int hargaKamar;
    int hargaTotal;
    private EditText edtTanggal;
    public Button btnSearch;
    private DatePickerDialog dpTanggal;
    Calendar newCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);
        dbHelper = new DatabaseHelper(Hotel.this);
        db = dbHelper.getReadableDatabase();

        final String[] lokasi = {"Bandung", "Yogyakarta", "Jakarta", "Bali", "Singapore", "Tokyo"};
        final String[] lama = {"1", "2", "3", "4"};
        final String[] kamar = {"1", "2", "3", "4"};

        spinLokasi = findViewById(R.id.lokasi);
        spinLama = findViewById(R.id.lama);
        spinKamar = findViewById(R.id.kamar);

        ArrayAdapter<CharSequence> adapterLokasi = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lokasi);
        adapterLokasi.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinLokasi.setAdapter(adapterLokasi);
        ArrayAdapter<CharSequence> adapterLama = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lama);
        adapterLama.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinLama.setAdapter(adapterLama);
        ArrayAdapter<CharSequence> adapterKamar = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kamar);
        adapterKamar.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinKamar.setAdapter(adapterKamar);

        spinLokasi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sLokasi = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinLama.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sLama = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinKamar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sKamar = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnSearch = findViewById(R.id.cari);
        edtTanggal = findViewById(R.id.tanggal);
        edtTanggal.setInputType(InputType.TYPE_NULL);
        edtTanggal.requestFocus();
        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        email = user.get(SessionManager.KEY_EMAIL);
        setDataTimeField();

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Hotel.this, SearchHotel.class);
                startActivity(intent);
            }
        });
    }
    private void setDataTimeField()
    {
        edtTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dpTanggal.show();
            }
        });
        dpTanggal = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, month, day);
                String[] bulan = {"January", "February", "March", "April", "May",
                        "June", "July", "August", "September", "October", "November", "December"};
                sTanggal = day + " " + bulan[month] + " " + year;
                edtTanggal.setText(sTanggal);
            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
    }
}