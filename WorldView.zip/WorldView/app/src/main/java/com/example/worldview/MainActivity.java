package com.example.worldview;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    AlertDialogManager alert = new AlertDialogManager();
    SessionManager session;
    Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        session = new SessionManager(getApplicationContext());
        session.checkLogin();
        btnLogout = findViewById(R.id.out);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).setTitle("Anda yakin ingin keluar?").setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        finish();
                        session.logoutUser();
                    }
                })
                        .setNegativeButton("Tidak", null)
                        .create();
                dialog.show();
            }
        });
    }
    public void profileMenu(View view) {
        Intent i = new Intent(this, Profile.class);
        startActivity(i);
    }
    public void historyMenu(View view) {
        Intent i = new Intent(this, History.class);
        startActivity(i);
    }
    public void bookPesawat(View view) {
        Intent i = new Intent(this, Pesawat.class);
        startActivity(i);
    }
    public void bookKereta(View view) {
        Intent i = new Intent(this, Kereta.class);
        startActivity(i);
    }
    public void bookHotel(View view) {
        Intent i = new Intent(this, Hotel.class);
        startActivity(i);
    }
}