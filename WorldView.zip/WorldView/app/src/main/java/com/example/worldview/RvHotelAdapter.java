package com.example.worldview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RvHotelAdapter extends RecyclerView.Adapter<RvHotelAdapter.RecycleViewHolder> {

    private ArrayList<HotelAdapter> hotelAdapters;
    public RvHotelAdapter(ArrayList<HotelAdapter> hotelAdapter){
        hotelAdapters = hotelAdapter;
    }

    @NonNull
    @Override
    public RvHotelAdapter.RecycleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_hotel, parent, false);
        RvHotelAdapter.RecycleViewHolder holder = new RvHotelAdapter.RecycleViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RvHotelAdapter.RecycleViewHolder holder, int position) {
        HotelAdapter item = hotelAdapters.get(position);
        holder.imageView.setImageResource(item.getGambarHotel());
        holder.namaHotel.setText(item.getNamaHotel());
        holder.lokasiHotel.setText(item.getLokasiHotel());
        holder.hargaHotel.setText(item.getHargaHotel());
    }

    @Override
    public int getItemCount() {
        return hotelAdapters.size();
    }

    public class RecycleViewHolder extends RecyclerView.ViewHolder{
        public ImageView imageView;
        public TextView namaHotel, lokasiHotel, hargaHotel;
        public RecycleViewHolder(@NonNull View view) {
            super(view);
            imageView = view.findViewById(R.id.rvHotel);
            namaHotel = view.findViewById(R.id.tvNamaHotel);
            lokasiHotel = view.findViewById(R.id.tvLokasiHotel);
            hargaHotel = view.findViewById(R.id.tvHargaHotel);
        }
    }
}
