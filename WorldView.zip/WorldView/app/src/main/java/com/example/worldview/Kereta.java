package com.example.worldview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Calendar;
import java.util.HashMap;

public class Kereta extends AppCompatActivity {

    protected Cursor cursor;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Spinner spinAsal, spinTujuan, spinDewasa, spinAnak;
    SessionManager session;
    String email;
    int id_book;
    public String sAsal, sTujuan, sTanggal, sDewasa, sAnak;
    int jmlDewasa, jmlAnak;
    int hargaDewasa, hargaAnak;
    int hargaTotalDewasa, hargaTotalAnak, hargaTotal;
    private EditText edtTanggal;
    public Button btnBook;
    private DatePickerDialog dpTanggal;
    Calendar newCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kereta);
        dbHelper = new DatabaseHelper(Kereta.this);
        db = dbHelper.getReadableDatabase();

        final String[] asal = {"Bandung", "Cirebon", "Jakarta", "Semarang", "Surabaya", "Yogyakarta"};
        final String[] tujuan = {"Bandung", "Cirebon", "Jakarta", "Semarang", "Surabaya", "Yogyakarta"};
        final String[] dewasa = {"1", "2", "3", "4"};
        final String[] anak = {"0", "1", "2", "3", "4"};

        spinAsal = findViewById(R.id.asal);
        spinTujuan = findViewById(R.id.tujuan);
        spinDewasa = findViewById(R.id.dewasa);
        spinAnak = findViewById(R.id.anak);

        ArrayAdapter<CharSequence> adapterAsal = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, asal);
        adapterAsal.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinAsal.setAdapter(adapterAsal);
        ArrayAdapter<CharSequence> adapterTujuan = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tujuan);
        adapterTujuan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinTujuan.setAdapter(adapterTujuan);
        ArrayAdapter<CharSequence> adapterDewasa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dewasa);
        adapterDewasa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinDewasa.setAdapter(adapterDewasa);
        ArrayAdapter<CharSequence> adapterAnak = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, anak);
        adapterAnak.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinAnak.setAdapter(adapterAnak);

        spinAsal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sAsal = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinTujuan.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sTujuan = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinDewasa.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sDewasa = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinAnak.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sAnak = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnBook = findViewById(R.id.book);
        edtTanggal = findViewById(R.id.tanggal);
        edtTanggal.setInputType(InputType.TYPE_NULL);
        edtTanggal.requestFocus();
        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        email = user.get(SessionManager.KEY_EMAIL);
        setDataTimeField();

        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                perhitunganHarga();
                if(sAsal != null && sTujuan != null && sTanggal != null && sDewasa != null) {
                    if((sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Bandung"))
                        || (sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Cirebon"))
                        || (sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Jakarta"))
                        || (sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Semarang"))
                        || (sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Surabaya"))
                        || (sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Yogyakarta"))) {
                        Toast.makeText(Kereta.this, "Asal dan Tujuan tidak boleh sama!", Toast.LENGTH_LONG).show();
                    } else{
                        AlertDialog dialog = new AlertDialog.Builder(Kereta.this)
                                .setTitle("Ingin booking pesawat sekarang?")
                                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            db.execSQL("INSERT INTO TB_BOOK (asal, tujuan, tanggal, dewasa, anak) VALUES ('" +
                                                    sAsal + "','" +
                                                    sTujuan + "','" +
                                                    sTanggal + "','" +
                                                    sDewasa + "','" +
                                                    sAnak + "');");
                                            cursor = db.rawQuery("SELECT id_book FROM TB_BOOK ORDER BY id_book DESC", null);
                                            cursor.moveToLast();
                                            if(cursor.getCount() > 0) {
                                                cursor.moveToPosition(0);
                                                id_book = cursor.getInt(0);
                                            }
                                            db.execSQL("INSERT INTO TB_HARGA (username, id_book, harga_dewasa, harga_anak, harga_total) VALUES ('" +
                                                    email + "','" +
                                                    id_book + "','" +
                                                    hargaTotalDewasa + "','" +
                                                    hargaTotalAnak + "','" +
                                                    hargaTotal + "');");
                                            Toast.makeText(Kereta.this, "Booking Berhasil", Toast.LENGTH_LONG).show();
                                            finish();
                                        } catch (Exception e){
                                            Toast.makeText(Kereta.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                })
                                .setNegativeButton("Tidak", null)
                                .create();
                        dialog.show();
                    }
                } else {
                    Toast.makeText(Kereta.this, "Mohon Lengkapi Data Pemesanan!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void perhitunganHarga() {
        if(sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Cirebon")) {
            hargaDewasa = 385000;
            hargaAnak = 365000;
        } else if(sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Jakarta")) {
            hargaDewasa = 150000;
            hargaAnak = 130000;
        } else if(sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Semarang")){
            hargaDewasa = 340000;
            hargaAnak = 320000;
        } else if(sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Surabaya")){
            hargaDewasa = 620000;
            hargaAnak = 600000;
        } else if(sAsal.equalsIgnoreCase("Bandung") && sTujuan.equalsIgnoreCase("Yogyakarta")){
            hargaDewasa = 425000;
            hargaAnak = 405000;
        } else if(sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Bandung")){
            hargaDewasa = 340000;
            hargaAnak = 320000;
        } else if(sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Jakarta")){
            hargaDewasa = 460000;
            hargaAnak = 440000;
        } else if(sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Semarang")){
            hargaDewasa = 340000;
            hargaAnak = 320000;
        } else if(sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Surabaya")){
            hargaDewasa = 450000;
            hargaAnak = 430000;
        } else if(sAsal.equalsIgnoreCase("Cirebon") && sTujuan.equalsIgnoreCase("Yogyakarta")){
            hargaDewasa = 375000;
            hargaAnak = 355000;
        } else if(sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Bandung")){
            hargaDewasa = 150000;
            hargaAnak = 130000;
        } else if(sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Cirebon")){
            hargaDewasa = 360000;
            hargaAnak = 340000;
        } else if(sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Semarang")){
            hargaDewasa = 360000;
            hargaAnak = 340000;
        } else if(sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Surabaya")){
            hargaDewasa = 765000;
            hargaAnak = 745000;
        } else if(sAsal.equalsIgnoreCase("Jakarta") && sTujuan.equalsIgnoreCase("Yogyakarta")){
            hargaDewasa = 475000;
            hargaAnak = 455000;
        } else if(sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Bandung")){
            hargaDewasa = 360000;
            hargaAnak = 340000;
        } else if(sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Cirebon")){
            hargaDewasa = 600000;
            hargaAnak = 580000;
        } else if(sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Jakarta")){
            hargaDewasa = 600000;
            hargaAnak = 580000;
        } else if(sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Surabaya")){
            hargaDewasa = 515000;
            hargaAnak = 495000;
        } else if(sAsal.equalsIgnoreCase("Semarang") && sTujuan.equalsIgnoreCase("Yogyakarta")){
            hargaDewasa = 325000;
            hargaAnak = 305000;
        } else if(sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Bandung")){
            hargaDewasa = 620000;
            hargaAnak = 600000;
        } else if(sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Cirebon")){
            hargaDewasa = 415000;
            hargaAnak = 395000;
        } else if(sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Jakarta")){
            hargaDewasa = 765000;
            hargaAnak = 745000;
        } else if(sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Semarang")){
            hargaDewasa = 385000;
            hargaAnak = 365000;
        } else if(sAsal.equalsIgnoreCase("Surabaya") && sTujuan.equalsIgnoreCase("Yogyakarta")){
            hargaDewasa = 405000;
            hargaAnak = 385000;
        } else if(sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Bandung")){
            hargaDewasa = 435000;
            hargaAnak = 415000;
        } else if(sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Cirebon")){
            hargaDewasa = 445000;
            hargaAnak = 425000;
        } else if(sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Jakarta")){
            hargaDewasa = 555000;
            hargaAnak = 535000;
        } else if(sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Semarang")){
            hargaDewasa = 325000;
            hargaAnak = 305000;
        } else if(sAsal.equalsIgnoreCase("Yogyakarta") && sTujuan.equalsIgnoreCase("Surabaya")){
            hargaDewasa = 380000;
            hargaAnak = 360000;
        }
        jmlDewasa = Integer.parseInt(sDewasa);
        jmlAnak = Integer.parseInt(sAnak);
        hargaTotalDewasa = jmlDewasa * hargaDewasa;
        hargaTotalAnak = jmlAnak * hargaAnak;
        hargaTotal = hargaTotalDewasa + hargaTotalAnak;
    }
    private void setDataTimeField(){
        edtTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dpTanggal.show();
            }
        });
        dpTanggal = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                String[] bulan = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
                sTanggal = dayOfMonth + " " + bulan[monthOfYear] + " " + year;
                edtTanggal.setText(sTanggal);

            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
    }
}